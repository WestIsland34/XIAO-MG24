import math, os, random
import numpy as np
from PIL import Image, ImageDraw

W, H = 96, 64
SS = 4  # supersample for vector drawings
OUT = "gifs"
os.makedirs(OUT, exist_ok=True)
ALL = {}

def save(name, frames, ms=50):
    frames = [f.convert("RGB") for f in frames]
    # RGB565 quantize to match SSD1331 colour depth
    q = []
    for f in frames:
        a = np.asarray(f).astype(np.uint16)
        a = np.stack([(a[..., 0] >> 3) << 3, (a[..., 1] >> 2) << 2, (a[..., 2] >> 3) << 3], -1).astype(np.uint8)
        q.append(Image.fromarray(a))
    q[0].save(f"{OUT}/{name}.gif", save_all=True, append_images=q[1:], duration=ms, loop=0, optimize=False, disposal=1)
    ALL[name] = (q, ms)

def canvas(bg=(0, 0, 0)):
    im = Image.new("RGB", (W * SS, H * SS), bg)
    return im, ImageDraw.Draw(im)

def down(im):
    return im.resize((W, H), Image.LANCZOS)

def S(*v):
    return [x * SS for x in v]

def hsv(h, s=1, v=1):
    h = h % 1.0
    i = int(h * 6); f = h * 6 - i
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    r, g, b = [(v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q)][i % 6]
    return (int(r * 255), int(g * 255), int(b * 255))

yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)

def hsv_np(h, s, v):
    h = (h % 1.0) * 6; i = np.floor(h).astype(int) % 6; f = h - np.floor(h)
    p = v * (1 - s); q = v * (1 - s * f); t = v * (1 - s * (1 - f))
    r = np.choose(i, [v, q, p, p, t, v]); g = np.choose(i, [t, v, v, q, p, p]); b = np.choose(i, [p, p, t, v, v, q])
    return Image.fromarray((np.stack([r, g, b], -1) * 255).clip(0, 255).astype(np.uint8))

# ================= 幾何学・エフェクト =================
def fx_plasma():
    fr = []
    for k in range(40):
        t = k / 40 * 2 * math.pi
        v = (np.sin(xx / 9 + t) + np.sin(yy / 7 - t) + np.sin((xx + yy) / 11 + t) + np.sin(np.hypot(xx - 48, yy - 32) / 6 - 2 * t)) / 4
        fr.append(hsv_np(v * 0.5 + k / 40, np.ones_like(v), np.full_like(v, 1.0)))
    save("fx01_plasma", fr)

def fx_starfield():
    random.seed(1)
    stars = [[random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(0.1, 1)] for _ in range(90)]
    fr = []
    N = 40
    for k in range(N):
        im = Image.new("RGB", (W, H)); d = ImageDraw.Draw(im)
        for x, y, z in stars:
            zz = (z - k / N) % 1.0 + 0.02
            px, py = 48 + x / zz * 30, 32 + y / zz * 30
            zz2 = zz + 0.04
            ox, oy = 48 + x / zz2 * 30, 32 + y / zz2 * 30
            c = int(255 * (1 - zz))
            d.line([ox, oy, px, py], fill=(c, c, min(255, c + 40)))
        fr.append(im)
    save("fx02_starfield", fr, 40)

def fx_cube():
    pts = [(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
    edges = [(a, b) for a in range(8) for b in range(a + 1, 8) if sum(pts[a][i] != pts[b][i] for i in range(3)) == 1]
    fr = []
    N = 48
    for k in range(N):
        a = k / N * 2 * math.pi
        im, d = canvas()
        P = []
        for x, y, z in pts:
            x, z = x * math.cos(a) - z * math.sin(a), x * math.sin(a) + z * math.cos(a)
            y, z = y * math.cos(a / 2 * 2) - z * math.sin(a), y * math.sin(a) + z * math.cos(a)
            f = 40 / (z + 4)
            P.append((S(48 + x * f)[0], S(32 + y * f)[0]))
        for e, (i, j) in enumerate(edges):
            d.line([P[i], P[j]], fill=hsv(e / 12 + k / N), width=SS)
        fr.append(down(im))
    save("fx03_cube3d", fr)

def fx_tunnel():
    dx, dy = xx - 48, yy - 32
    r = np.hypot(dx, dy) + 0.5
    ang = np.arctan2(dy, dx) / (2 * np.pi)
    fr = []
    N = 40
    for k in range(N):
        u = 24 / r + k / N * 2
        chk = ((np.floor(u * 4) + np.floor(ang * 16)) % 2)
        v = np.clip(r / 40, 0, 1) * (0.4 + 0.6 * chk)
        fr.append(hsv_np(u * 0.25, np.full_like(v, 0.8), v))
    save("fx04_tunnel", fr)

def fx_spiral():
    dx, dy = xx - 48, yy - 32
    r = np.hypot(dx, dy); ang = np.arctan2(dy, dx)
    fr = []
    N = 36
    for k in range(N):
        t = k / N * 2 * np.pi
        v = (np.sin(ang * 3 + r / 3 - t) > 0).astype(np.float32)
        fr.append(hsv_np(r / 60 - k / N, np.ones_like(v), v * 0.9 + 0.05))
    save("fx05_spiral", fr)

def fx_bounce():
    random.seed(3)
    balls = [[random.uniform(8, 88), random.uniform(8, 56), random.choice([-1, 1]) * random.uniform(1, 2.2), random.choice([-1, 1]) * random.uniform(1, 2), random.uniform(3, 6), hsv(i / 6)] for i in range(6)]
    fr = []
    for k in range(80):
        im, d = canvas()
        for b in balls:
            b[0] += b[2]; b[1] += b[3]
            if b[0] < b[4] or b[0] > W - b[4]: b[2] *= -1
            if b[1] < b[4] or b[1] > H - b[4]: b[3] *= -1
            x, y, r = b[0], b[1], b[4]
            d.ellipse(S(x - r, y - r, x + r, y + r), fill=b[5])
            d.ellipse(S(x - r * .5, y - r * .6, x - r * .1, y - r * .2), fill=(255, 255, 255))
        fr.append(down(im))
    save("fx06_bounce_balls", fr, 40)

def fx_matrix():
    random.seed(5)
    cols = [[random.uniform(-64, 64), random.uniform(1, 2.5)] for _ in range(16)]
    fr = []
    for k in range(60):
        im = Image.new("RGB", (W, H)); d = ImageDraw.Draw(im)
        for i, c in enumerate(cols):
            head = (c[0] + k * c[1]) % 100 - 10
            for j in range(14):
                y = int(head) - j * 4
                if 0 <= y < H:
                    g = 255 if j == 0 else int(220 * (1 - j / 14))
                    col = (200, 255, 200) if j == 0 else (0, g, 0)
                    # pseudo glyph 3x4
                    rnd = random.Random(i * 1000 + y // 4 + k // 6)
                    for gx in range(3):
                        for gy in range(3):
                            if rnd.random() > 0.45:
                                d.point((i * 6 + 1 + gx, y + gy), fill=col)
        fr.append(im)
    save("fx07_matrix_rain", fr, 60)

def fx_fire():
    rng = np.random.default_rng(2)
    f = np.zeros((H + 2, W), np.float32)
    pal = []
    for i in range(256):
        t = i / 255
        pal.append((min(255, int(t * 3 * 255)), min(255, max(0, int((t * 3 - 1) * 255))), min(255, max(0, int((t * 3 - 2) * 255)))))
    pal = np.array(pal, np.uint8)
    fr = []
    for k in range(70):
        f[-1] = rng.random(W) * 255 * (rng.random(W) > 0.3)
        f[-2] = f[-1]
        up = (np.roll(f, -1, 0) + np.roll(np.roll(f, -1, 0), 1, 1) + np.roll(np.roll(f, -1, 0), -1, 1) + np.roll(f, -2, 0)) / 4.08
        f[:-2] = up[:-2]
        if k >= 30:
            fr.append(Image.fromarray(pal[f[:H].clip(0, 255).astype(np.uint8)]))
    save("fx08_fire", fr, 50)

def fx_waves():
    fr = []
    N = 40
    for k in range(N):
        t = k / N * 2 * math.pi
        im, d = canvas()
        for j in range(5):
            pts = [S(x, 32 + 18 * math.sin(x / 12 + t + j * 0.7) * math.cos(t * 1 + j) * (1 - j * 0.12)) for x in range(0, W + 1, 2)]
            d.line(pts, fill=hsv(j / 5 + k / N), width=SS + 1)
        fr.append(down(im))
    save("fx09_sine_waves", fr)

def fx_fountain():
    random.seed(9)
    ps = []
    fr = []
    for k in range(90):
        for _ in range(4):
            ps.append([48, 62, random.uniform(-1.2, 1.2), random.uniform(-3.4, -2.4), random.random(), 0])
        im = Image.new("RGB", (W, H)); d = ImageDraw.Draw(im)
        for p in ps:
            p[0] += p[2]; p[1] += p[3]; p[3] += 0.09; p[5] += 1
            c = hsv(p[4], 1, max(0.2, 1 - p[5] / 60))
            d.rectangle([p[0], p[1], p[0] + 1, p[1] + 1], fill=c)
        ps = [p for p in ps if p[1] < H]
        if k >= 30: fr.append(im)
    save("fx10_fountain", fr, 40)

def fx_rings():
    fr = []
    N = 32
    for k in range(N):
        im, d = canvas()
        for i in range(8, -1, -1):
            r = ((i + k / N) * 8)
            c = hsv(i / 9 - k / N * 0.1, 0.9, max(0, 1 - r / 70))
            d.ellipse(S(48 - r, 32 - r, 48 + r, 32 + r), outline=c, width=SS * 2)
        fr.append(down(im))
    save("fx11_rings", fr)

def fx_lissajous():
    fr = []
    N = 60
    for k in range(N):
        ph = k / N * 2 * math.pi
        im, d = canvas()
        pts = [S(48 + 40 * math.sin(3 * t + ph), 32 + 26 * math.sin(2 * t)) for t in np.linspace(0, 2 * math.pi, 300)]
        for i in range(len(pts) - 1):
            d.line([pts[i], pts[i + 1]], fill=hsv(i / 300 + k / N), width=SS)
        fr.append(down(im))
    save("fx12_lissajous", fr)

# ================= 顔・キャラクター =================
def eyes(d, lx, rx, y, open_, look=0, col=(0, 220, 255), shape="round"):
    for cx in (lx, rx):
        h = 14 * open_
        if h < 1.5:
            d.rectangle(S(cx - 9, y - 1, cx + 9, y + 1), fill=col)
        else:
            d.rounded_rectangle(S(cx - 9, y - h, cx + 9, y + h), radius=SS * 6, fill=col)
            if open_ > 0.5:
                d.ellipse(S(cx - 4 + look, y - 6, cx + 2 + look, y), fill=(255, 255, 255))

def face_blink():
    fr = []
    seq = [1] * 20 + [0.6, 0.2, 0.05, 0.2, 0.6] + [1] * 10 + [0.5, 0.05, 0.5, 1, 0.5, 0.05, 0.5] + [1] * 8
    for i, o in enumerate(seq):
        im, d = canvas(); eyes(d, 28, 68, 30, o); fr.append(down(im))
    save("face01_blink", fr, 60)

def face_look():
    fr = []
    N = 60
    for k in range(N):
        lk = 0
        if 10 <= k < 25: lk = min(1, (k - 10) / 4) * 7
        elif 25 <= k < 30: lk = 7 - (k - 25) / 5 * 14
        elif 30 <= k < 45: lk = -7
        elif 45 <= k < 50: lk = -7 + (k - 45) / 5 * 7
        im, d = canvas()
        for cx in (28, 68):
            d.ellipse(S(cx - 13, 18, cx + 13, 44), fill=(240, 240, 240))
            d.ellipse(S(cx - 6 + lk, 25, cx + 6 + lk, 37), fill=(30, 30, 30))
            d.ellipse(S(cx - 3 + lk, 27, cx + 0 + lk, 30), fill=(255, 255, 255))
        fr.append(down(im))
    save("face02_look_around", fr, 50)

def face_happy():
    fr = []
    N = 30
    for k in range(N):
        b = math.sin(k / N * 2 * math.pi) * 3
        im, d = canvas()
        for cx in (30, 66):
            d.arc(S(cx - 10, 18 + b, cx + 10, 38 + b), 200, 340, fill=(255, 200, 0), width=SS * 3)
        d.chord(S(36, 36 + b, 60, 56 + b), 0, 180, fill=(255, 90, 90))
        d.ellipse(S(12, 38 + b, 22, 44 + b), fill=(255, 120, 160))
        d.ellipse(S(74, 38 + b, 84, 44 + b), fill=(255, 120, 160))
        fr.append(down(im))
    save("face03_happy", fr, 50)

def face_sleepy():
    fr = []
    N = 60
    for k in range(N):
        im, d = canvas()
        b = math.sin(k / N * 2 * math.pi) * 1.5
        for cx in (26, 58):
            d.arc(S(cx - 9, 26 + b, cx + 9, 40 + b), 20, 160, fill=(120, 160, 255), width=SS * 2)
        for i in range(3):
            ph = (k / N + i / 3) % 1
            x, y = 72 + ph * 16, 34 - ph * 30
            s = 3 + ph * 4
            c = int(255 * (1 - ph))
            d.line(S(x, y, x + s, y, x, y + s, x + s, y + s), fill=(c, c, c), width=SS)
        fr.append(down(im))
    save("face04_sleepy_zzz", fr, 60)

def face_angry():
    fr = []
    for k in range(30):
        sh = random.Random(k).uniform(-1.5, 1.5) if k % 10 < 6 else 0
        im, d = canvas()
        for cx, s in ((28, 1), (68, -1)):
            d.polygon(S(cx - 11 + sh, 22, cx + 11 + sh, 22, cx + 11 * s + sh, 22 + 0)[:4] + S(cx + 11 * s + sh, 34, cx - 11 * s + sh, 28) if False else S(cx - 11 + sh, 22 + (8 if s < 0 else 0), cx + 11 + sh, 22 + (8 if s > 0 else 0), cx + 11 + sh, 40, cx - 11 + sh, 40), fill=(255, 40, 30))
            d.ellipse(S(cx - 4 + sh, 31, cx + 4 + sh, 39), fill=(40, 0, 0))
        d.line(S(36 + sh, 54, 48 + sh, 50, 60 + sh, 54), fill=(255, 40, 30), width=SS * 2)
        fr.append(down(im))
    save("face05_angry", fr, 50)

def face_hearts():
    fr = []
    N = 30
    def heart(d, cx, cy, s, c):
        d.ellipse(S(cx - s, cy - s * .6, cx, cy + s * .3), fill=c)
        d.ellipse(S(cx, cy - s * .6, cx + s, cy + s * .3), fill=c)
        d.polygon(S(cx - s * .97, cy, cx + s * .97, cy, cx, cy + s), fill=c)
    for k in range(N):
        sc = 1 + 0.18 * max(0, math.sin(k / N * 4 * math.pi))
        im, d = canvas()
        heart(d, 28, 28, 12 * sc, (255, 50, 110)); heart(d, 68, 28, 12 * sc, (255, 50, 110))
        d.arc(S(38, 40, 58, 54), 20, 160, fill=(255, 150, 180), width=SS * 2)
        fr.append(down(im))
    save("face06_heart_eyes", fr, 50)

def face_surprised():
    fr = []
    seq = [0.3] * 8 + [0.6, 1.0, 1.25, 1.15, 1.2] + [1.2] * 14 + [0.9, 0.6, 0.3]
    for o in seq:
        im, d = canvas()
        for cx in (28, 68):
            r = 10 * o
            d.ellipse(S(cx - r, 26 - r, cx + r, 26 + r), fill=(255, 255, 255))
            d.ellipse(S(cx - r * .35, 26 - r * .35, cx + r * .35, 26 + r * .35), fill=(0, 0, 0))
        m = 3 + 4 * o
        d.ellipse(S(48 - m * .7, 50 - m, 48 + m * .7, 50 + m), outline=(255, 200, 60), width=SS * 2)
        fr.append(down(im))
    save("face07_surprised", fr, 60)

def face_robot():
    fr = []
    N = 40
    for k in range(N):
        im, d = canvas()
        d.rounded_rectangle(S(8, 6, 88, 60), radius=SS * 8, outline=(120, 120, 140), width=SS * 2)
        sx = 18 + (1 - abs((k / N) * 2 - 1)) * 54
        d.rectangle(S(16, 20, 80, 32), fill=(30, 0, 0))
        for i in range(10):
            a = max(0, 1 - abs(i - (sx - 16) / 6.4) / 3)
            if a > 0:
                d.rectangle(S(16 + i * 6.4, 20, 16 + i * 6.4 + 6, 32), fill=(int(255 * a), 0, 0))
        for i in range(7):
            h = 2 + abs(math.sin(k / 3 + i)) * 6 * (k % 20 < 14)
            d.rectangle(S(26 + i * 6, 48 - h / 2, 30 + i * 6, 48 + h / 2), fill=(0, 200, 120))
        fr.append(down(im))
    save("face08_robot", fr, 50)

# ================= インジケータ =================
def ind_spinner():
    fr = []
    N = 24
    for k in range(N):
        im, d = canvas()
        for i in range(12):
            a = i / 12 * 2 * math.pi
            age = (k / N * 12 - i) % 12
            c = int(255 * max(0.12, 1 - age / 12))
            d.line(S(48 + 12 * math.cos(a), 32 + 12 * math.sin(a), 48 + 22 * math.cos(a), 32 + 22 * math.sin(a)), fill=(0, c, c), width=SS * 3)
        fr.append(down(im))
    save("ind01_spinner", fr, 50)

def ind_arc():
    fr = []
    N = 40
    for k in range(N):
        t = k / N
        st = t * 720
        ln = 40 + 230 * (0.5 - 0.5 * math.cos(t * 2 * math.pi))
        im, d = canvas()
        d.arc(S(26, 10, 70, 54), 0, 360, fill=(40, 40, 60), width=SS * 4)
        d.arc(S(26, 10, 70, 54), st, st + ln, fill=hsv(t), width=SS * 4)
        fr.append(down(im))
    save("ind02_arc_loader", fr, 40)

def ind_progress():
    from PIL import ImageFont
    font = ImageFont.load_default()
    fr = []
    N = 50
    for k in range(N + 10):
        p = min(1, k / N)
        im, d = canvas()
        d.rounded_rectangle(S(8, 26, 88, 40), radius=SS * 3, outline=(200, 200, 200), width=SS)
        w = 76 * p
        if w > 1:
            d.rounded_rectangle(S(10, 28, 10 + w, 38), radius=SS * 2, fill=hsv(0.33 * p, 0.9, 1) if p < 1 else (0, 255, 80))
        sm = down(im); dd = ImageDraw.Draw(sm)
        txt = f"{int(p * 100)}%"
        dd.text((48 - len(txt) * 3, 46), txt, fill=(255, 255, 255), font=font)
        fr.append(sm)
    save("ind03_progress_bar", fr, 50)

def ind_battery():
    fr = []
    N = 5
    for k in range(N * 6):
        lv = (k // 6) % N
        im, d = canvas()
        d.rounded_rectangle(S(14, 16, 76, 48), radius=SS * 3, outline=(220, 220, 220), width=SS * 2)
        d.rectangle(S(76, 26, 82, 38), fill=(220, 220, 220))
        for i in range(lv):
            c = (255, 60, 40) if lv == 1 else (255, 200, 0) if lv == 2 else (0, 230, 80)
            d.rectangle(S(19 + i * 14, 21, 30 + i * 14, 43), fill=c)
        if k % 6 < 4:
            d.polygon(S(50, 18, 38, 34, 47, 34, 42, 46, 56, 28, 47, 28), fill=(255, 255, 120), outline=(0, 0, 0))
        fr.append(down(im))
    save("ind04_battery_charge", fr, 100)

def ind_wifi():
    fr = []
    for k in range(5 * 6):
        lv = (k // 6) % 5
        im, d = canvas()
        for i in range(3):
            r = 12 + i * 12
            c = (0, 200, 255) if i < lv - 1 or (lv == 4) else (50, 50, 60)
            d.arc(S(48 - r, 54 - r, 48 + r, 54 + r), 225, 315, fill=c, width=SS * 4)
        d.ellipse(S(44, 50, 52, 58), fill=(0, 200, 255) if lv > 0 else (50, 50, 60))
        fr.append(down(im))
    save("ind05_wifi", fr, 100)

def ind_signal():
    fr = []
    for k in range(36):
        lv = [0, 1, 2, 3, 4, 4, 3, 4][(k // 5) % 8] if k < 40 else 4
        lv = min(4, k // 6)
        im, d = canvas()
        for i in range(4):
            h = 10 + i * 10
            c = (0, 255, 120) if i < lv else (50, 50, 60)
            d.rectangle(S(20 + i * 16, 56 - h, 30 + i * 16, 56), fill=c)
        fr.append(down(im))
    save("ind06_signal_bars", fr, 80)

def ind_ecg():
    base = []
    for x in range(96):
        p = x % 48
        y = 0
        if 8 <= p < 14: y = -3 * math.sin((p - 8) / 6 * math.pi)
        elif p == 18: y = 4
        elif p == 20: y = -22
        elif p == 22: y = 8
        elif 30 <= p < 38: y = -5 * math.sin((p - 30) / 8 * math.pi)
        base.append(y)
    fr = []
    N = 48
    for k in range(N):
        im, d = canvas()
        for gx in range(0, 96, 12): d.line(S(gx, 0, gx, 64), fill=(0, 40, 0))
        for gy in range(0, 64, 12): d.line(S(0, gy, 96, gy), fill=(0, 40, 0))
        pts = [S(x, 36 + base[(x + k * 2) % 96]) for x in range(96)]
        d.line(pts, fill=(0, 255, 100), width=SS * 2)
        fr.append(down(im))
    save("ind07_heartbeat_ecg", fr, 40)

def ind_hourglass():
    fr = []
    N = 40
    for k in range(N + 10):
        im, d = canvas()
        rot = 0
        p = min(1, k / N)
        g = Image.new("RGBA", (40 * SS, 56 * SS), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        gd.polygon(S(4, 2, 36, 2, 22, 28, 36, 54, 4, 54, 18, 28), outline=(200, 200, 220), width=SS * 2)
        # top sand
        ht = 22 * (1 - p)
        if ht > 0.5:
            w = ht / 24 * 14
            gd.polygon(S(20 - w - 2, 28 - ht, 20 + w + 2, 28 - ht, 20, 27), fill=(255, 190, 60))
        hb = 20 * p
        if hb > 0.5:
            gd.polygon(S(7, 52, 33, 52, 20, 52 - hb), fill=(255, 190, 60))
        if p < 1:
            gd.line(S(20, 28, 20, 52 - hb), fill=(255, 190, 60), width=SS)
        if k >= N:
            g = g.rotate((k - N) / 10 * 180, resample=Image.BICUBIC)
        im.paste(g, S(28, 4), g)
        fr.append(down(im))
    save("ind08_hourglass", fr, 60)

def ind_dots():
    fr = []
    N = 30
    for k in range(N):
        im, d = canvas()
        for i in range(3):
            b = max(0, math.sin((k / N - i * 0.12) * 2 * math.pi)) * 10
            d.ellipse(S(26 + i * 18 - 5, 36 - b - 5, 26 + i * 18 + 5, 36 - b + 5), fill=hsv(0.55 + i * 0.1))
        fr.append(down(im))
    save("ind09_bouncing_dots", fr, 40)

def ind_equalizer():
    fr = []
    rng = random.Random(4)
    hs = [10] * 12
    for k in range(40):
        im, d = canvas()
        for i in range(12):
            tgt = 8 + abs(math.sin(k * 0.3 + i * 0.7) * math.cos(k * 0.11 + i)) * 48
            hs[i] += (tgt - hs[i]) * 0.5
            for s in range(int(hs[i] // 4)):
                d.rectangle(S(4 + i * 7.6, 60 - s * 4 - 3, 4 + i * 7.6 + 6, 60 - s * 4), fill=hsv(0.33 - s / 16 * 0.33))
        fr.append(down(im))
    save("ind10_equalizer", fr, 60)

# ================= 乗り物・ラジコン =================
def sky(d, k, N, cloud_speed=1):
    for y in range(64):
        c = (int(60 + y * 1.5), int(130 + y * 1.4), 255)
        d.line(S(0, y, 96, y), fill=c, width=SS)
    for cx, cy, s in ((10, 12, 1), (60, 8, 0.8), (90, 20, 1.2)):
        x = (cx - k / N * 96 * cloud_speed) % 130 - 20
        for ox, oy, r in ((0, 0, 6), (6, -2, 7), (12, 0, 5)):
            d.ellipse(S(x + ox * s - r * s, cy + oy - r * s * .7, x + ox * s + r * s, cy + oy + r * s * .7), fill=(255, 255, 255))

def veh_heli():
    fr = []
    N = 40
    for k in range(N):
        im, d = canvas()
        sky(d, k, N)
        bob = math.sin(k / N * 4 * math.pi) * 2
        y = 34 + bob
        # tail
        d.polygon(S(44, y - 3, 84, y - 2, 84, y + 1, 44, y + 3), fill=(220, 40, 40))
        d.polygon(S(82, y - 9, 86, y - 9, 86, y + 1, 82, y + 1), fill=(220, 40, 40))
        tr = k % 4
        d.line(S(84, y - 4 - tr * 2, 84, y + 4 - (3 - tr) * 2 + 2), fill=(60, 60, 60), width=SS)
        # body
        d.ellipse(S(22, y - 10, 52, y + 10), fill=(230, 40, 40))
        d.chord(S(24, y - 8, 40, y + 6), 90, 270, fill=(120, 200, 255))
        # skids
        d.line(S(26, y + 10, 30, y + 14), fill=(50, 50, 50), width=SS)
        d.line(S(44, y + 10, 40, y + 14), fill=(50, 50, 50), width=SS)
        d.line(S(20, y + 14, 50, y + 14), fill=(50, 50, 50), width=SS)
        # mast & rotor
        d.line(S(38, y - 10, 38, y - 14), fill=(60, 60, 60), width=SS * 2)
        ph = k / 2.0 * math.pi
        L = 30 * abs(math.cos(ph))
        d.line(S(38 - L, y - 14, 38 + L, y - 14), fill=(40, 40, 40), width=SS * 2)
        d.line(S(8, y - 14, 68, y - 14), fill=(90, 90, 110), width=SS // 2)
        fr.append(down(im))
    save("veh01_helicopter", fr, 40)

def veh_plane():
    fr = []
    N = 60
    for k in range(N):
        im, d = canvas()
        sky(d, k, N, 2)
        t = k / N * 2 * math.pi
        y = 32 + math.sin(t) * 8
        ang = math.cos(t) * 8
        g = Image.new("RGBA", (60 * SS, 30 * SS), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        gd.ellipse(S(8, 11, 50, 19), fill=(255, 210, 0))
        gd.polygon(S(22, 15, 34, 15, 30, 27, 24, 27), fill=(230, 120, 0))
        gd.polygon(S(8, 15, 14, 15, 10, 6, 5, 6), fill=(230, 120, 0))
        gd.ellipse(S(32, 11, 42, 15), fill=(120, 200, 255))
        p = abs(math.sin(k * 1.7)) * 7
        gd.line(S(51, 15 - p, 51, 15 + p), fill=(80, 80, 80), width=SS)
        g = g.rotate(ang, resample=Image.BICUBIC)
        im.paste(g, (int(18 * SS), int((y - 15) * SS)), g)
        fr.append(down(im))
    save("veh02_airplane", fr, 50)

def veh_bike():
    fr = []
    N = 60
    for k in range(N):
        t = k / N * 2 * math.pi
        lean = math.sin(t) * 40
        im, d = canvas((30, 30, 40))
        # road
        d.rectangle(S(0, 50, 96, 64), fill=(60, 60, 70))
        for i in range(6):
            x = (i * 24 - k * 4) % 120 - 12
            d.rectangle(S(x, 56, x + 10, 58), fill=(240, 240, 240))
        # bike viewed from front/behind, leaning
        g = Image.new("RGBA", (80 * SS, 50 * SS), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        o = 20
        gd.rounded_rectangle(S(o+17, 30, o+23, 48), radius=SS * 2, fill=(20, 20, 20))
        gd.rounded_rectangle(S(o+12, 18, o+28, 34), radius=SS * 3, fill=(0, 120, 255))
        gd.ellipse(S(o+16, 20, o+24, 26), fill=(255, 240, 150))
        gd.ellipse(S(o+14, 4, o+26, 16), fill=(255, 255, 255))
        gd.rectangle(S(o+15, 8, o+25, 11), fill=(40, 40, 40))
        gd.line(S(o+12, 20, o+6, 30), fill=(200, 0, 0), width=SS * 3)
        gd.line(S(o+28, 20, o+34, 30), fill=(200, 0, 0), width=SS * 3)
        g = g.rotate(lean, resample=Image.BICUBIC, center=(40 * SS, 48 * SS))
        im.paste(g, (int(8 * SS), int(8 * SS)), g)
        fr.append(down(im))
    save("veh03_bike_lean", fr, 50)

def veh_buggy():
    fr = []
    N = 40
    for k in range(N):
        im, d = canvas((140, 200, 255))
        # hills scroll
        gpts = [S(x, 50 + 4 * math.sin((x + k * 3) / 10)) for x in range(-2, 99, 2)]
        d.polygon(gpts + S(98, 64, -2, 64), fill=(150, 100, 50))
        def gy(x): return 50 + 4 * math.sin((x + k * 3) / 10)
        r1, r2 = 30, 62
        y1, y2 = gy(r1) - 7, gy(r2) - 7
        ang = math.degrees(math.atan2(y2 - y1, r2 - r1))
        g = Image.new("RGBA", (56 * SS, 30 * SS), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        gd.polygon(S(4, 16, 14, 8, 36, 8, 52, 14, 52, 18, 4, 20), fill=(240, 60, 20))
        gd.polygon(S(16, 8, 22, 2, 34, 2, 36, 8), fill=(40, 40, 60))
        gd.rectangle(S(2, 6, 10, 8), fill=(30, 30, 30))
        g = g.rotate(-ang, resample=Image.BICUBIC)
        cy = (y1 + y2) / 2
        im.paste(g, (int(18 * SS), int((cy - 18) * SS)), g)
        for x, y in ((r1, y1), (r2, y2)):
            d.ellipse(S(x - 7, y - 7, x + 7, y + 7), fill=(25, 25, 25))
            d.ellipse(S(x - 3, y - 3, x + 3, y + 3), fill=(200, 200, 200))
            a = -k * 0.8
            d.line(S(x, y, x + 6 * math.cos(a), y + 6 * math.sin(a)), fill=(90, 90, 90), width=SS)
        # dust
        for i in range(4):
            ph = (k / 6 + i / 4) % 1
            d.ellipse(S(r1 - 10 - ph * 18 - 3 * ph, y1 + 4 - ph * 6 - 3 * ph, r1 - 10 - ph * 18 + 3 * ph, y1 + 4 - ph * 6 + 3 * ph), fill=(200, 170, 130))
        fr.append(down(im))
    save("veh04_buggy", fr, 40)

def veh_drone():
    fr = []
    N = 40
    for k in range(N):
        im, d = canvas()
        sky(d, k, N, 0.5)
        y = 28 + math.sin(k / N * 2 * math.pi) * 3
        x = 48 + math.sin(k / N * 4 * math.pi) * 3
        for sx in (-1, 1):
            d.line(S(x, y, x + sx * 26, y - 4), fill=(50, 50, 50), width=SS * 2)
            d.rectangle(S(x + sx * 26 - 1, y - 8, x + sx * 26 + 1, y - 4), fill=(50, 50, 50))
            L = 12 * abs(math.cos(k * 1.3 + sx))
            d.line(S(x + sx * 26 - L, y - 8, x + sx * 26 + L, y - 8), fill=(30, 30, 30), width=SS)
            d.ellipse(S(x + sx * 26 - 12, y - 9, x + sx * 26 + 12, y - 7), outline=(120, 120, 140), width=1)
        d.rounded_rectangle(S(x - 10, y - 4, x + 10, y + 4), radius=SS * 2, fill=(240, 240, 240))
        d.ellipse(S(x - 3, y + 3, x + 3, y + 9), fill=(30, 30, 30))
        led = (255, 0, 0) if k % 10 < 5 else (60, 0, 0)
        d.ellipse(S(x - 1.5, y - 2.5, x + 1.5, y + .5), fill=led)
        # payload on string
        sw = math.sin(k / N * 4 * math.pi + 1) * 4
        d.line(S(x, y + 6, x + sw, y + 26), fill=(80, 60, 40), width=SS // 2)
        d.rectangle(S(x + sw - 4, y + 26, x + sw + 4, y + 32), fill=(200, 130, 50))
        fr.append(down(im))
    save("veh05_drone", fr, 40)

def veh_car_top():
    fr = []
    N = 60
    for k in range(N):
        im, d = canvas((40, 120, 40))
        d.ellipse(S(8, 6, 88, 58), fill=(70, 70, 80))
        d.ellipse(S(26, 20, 70, 44), fill=(40, 120, 40))
        a = k / N * 2 * math.pi
        cx, cy = 48 + 31 * math.cos(a), 32 + 19 * math.sin(a)
        g = Image.new("RGBA", (16 * SS, 10 * SS), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        gd.rounded_rectangle(S(1, 2, 15, 8), radius=SS * 2, fill=(255, 220, 0))
        gd.rectangle(S(6, 3, 10, 7), fill=(30, 30, 50))
        for wx in (3, 11):
            gd.rectangle(S(wx - 2, 0, wx + 2, 2), fill=(10, 10, 10)); gd.rectangle(S(wx - 2, 8, wx + 2, 10), fill=(10, 10, 10))
        heading = math.degrees(math.atan2(19 * math.cos(a), -31 * math.sin(a)))
        g = g.rotate(-heading, expand=True, resample=Image.BICUBIC)
        im.paste(g, (int(cx * SS - g.width / 2), int(cy * SS - g.height / 2)), g)
        fr.append(down(im))
    save("veh06_rc_car_track", fr, 40)

for fn in [fx_plasma, fx_starfield, fx_cube, fx_tunnel, fx_spiral, fx_bounce, fx_matrix, fx_fire, fx_waves, fx_fountain, fx_rings, fx_lissajous,
           face_blink, face_look, face_happy, face_sleepy, face_angry, face_hearts, face_surprised, face_robot,
           ind_spinner, ind_arc, ind_progress, ind_battery, ind_wifi, ind_signal, ind_ecg, ind_hourglass, ind_dots, ind_equalizer,
           veh_heli, veh_plane, veh_bike, veh_buggy, veh_drone, veh_car_top]:
    fn()

# preview sheet: 3x scale, 6 columns
names = sorted(ALL)
cols, sc, pad = 6, 2, 4
rows = math.ceil(len(names) / cols)
PW, PH = cols * (W * sc + pad) + pad, rows * (H * sc + pad) + pad
pf = []
for k in range(60):
    im = Image.new("RGB", (PW, PH), (60, 60, 60))
    for i, n in enumerate(names):
        frs, _ = ALL[n]
        f = frs[k % len(frs)].resize((W * sc, H * sc), Image.NEAREST)
        im.paste(f, (pad + (i % cols) * (W * sc + pad), pad + (i // cols) * (H * sc + pad)))
    pf.append(im)
pf[0].save("preview_all.gif", save_all=True, append_images=pf[1:], duration=60, loop=0)
for n in names:
    print(n, len(ALL[n][0]), os.path.getsize(f"{OUT}/{n}.gif"))
